'use strict';

/**
 * @ngdoc function
 * @name meanApp1App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the meanApp1App
 */
angular.module('meanApp1App')
  .controller('DatosCtrl', 
  	function ($scope,$http,$location,$rootScope) {
    $scope.root=$rootScope;     
          
    $scope.getEmail = function() {
      

      //https://www.googleapis.com/plus/v1/people/me?access_token={YOUR_API_KEY}
      //llamando al API de google usando token oauth 2.0
     //?access_token='+$scope.root.token.access_token).
      //$http.get('https://www.googleapis.com/plus/v1/people/me', { headers: {'Authorization': 'Bearer ' + $scope.root.token.access_token} }).
      //$http.get('https://www.googleapis.com/plus/v1/people/me?access_token='+$scope.root.token.access_token).
      $http.get('https://www.googleapis.com/plus/v1/people/me?access_token='+$scope.root.token.access_token).
        success(function(data, status, headers, config) {
          $scope.data = data;
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          alert(data);
        });
              
    };      
    
    $scope.getDatosLogin = function() {
      

      //https://www.googleapis.com/plus/v1/people/me?access_token={YOUR_API_KEY}
      //llamando al API de google usando token oauth 2.0
     //?access_token='+$scope.root.token.access_token).
      //$http.get('https://www.googleapis.com/plus/v1/people/me', { headers: {'Authorization': 'Bearer ' + $scope.root.token.access_token} }).
      //$http.get('https://www.googleapis.com/plus/v1/people/me?access_token='+$scope.root.token.access_token).
      $http.get('https://www.googleapis.com/plus/v1/people/me', { headers: {'Authorization': 'Bearer ' + $scope.root.token.access_token} }).
        success(function(data, status, headers, config) {
          $scope.user = data;
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          alert(data);
        });
              
    };   

  });
/*

*/